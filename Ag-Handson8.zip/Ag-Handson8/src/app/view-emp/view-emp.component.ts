import { Component, OnInit } from '@angular/core';
import { Department } from 'src/Model/Department';
import { Employee } from 'src/Model/Employee';
import { Skill } from 'src/Model/Skill';

@Component({
  selector: 'app-view-emp',
  templateUrl: './view-emp.component.html',
  styleUrls: ['./view-emp.component.css']
})
export class ViewEmpComponent implements OnInit {
  emp!:Employee;
  dept!:Department;
  skill!:Skill[];
  constructor() { }

  ngOnInit(): void {
    this.dept={id:1,name:"payroll"};
    this.skill=[{id:1,name:"HTML"},{id:2,name:"CSS"},{id:3,name:"JAVASCRIPT"}]
    this.emp = {
      id:3,
      name:"John",
      salary:10000,
      permanent:true,
      department:this.dept,
      skill:this.skill,
      dateOfBirth:new Date('04/21/2019'),
    }
  }

}
