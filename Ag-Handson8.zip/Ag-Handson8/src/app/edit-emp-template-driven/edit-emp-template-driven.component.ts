import { Component, OnInit } from '@angular/core';
import { Department } from 'src/Model/Department';
import { Employee } from 'src/Model/Employee';

@Component({
  selector: 'app-edit-emp-template-driven',
  templateUrl: './edit-emp-template-driven.component.html',
  styleUrls: ['./edit-emp-template-driven.component.css']
})
export class EditEmpTemplateDrivenComponent implements OnInit {
  employee:Employee=
  {
     id:3,
     name:"John",
     salary:10000,
     permanent:false,
     department:{id:1,name:"PayRoll"},
     skill:[{id:1,name:"HTML"},{id:2,name:"CSS"},{id:3,name:"JavaScript"}],
     dateOfBirth:new Date("2019-04-20"),
     //photoURL:""
  };

  //Creating array for drop down list.
  departments:Department[]=[];

  
  constructor() { }

  ngOnInit(): void {
    this.departments=[{id:1,name:"Payroll"},{id:2,name:"Internal"},{id:3,name:"HR"}];
  }
  // dept:any=this.departments[0];
  // value(id:any):void{
  //   console.log(id);
  //   this.dept=this.departments.filter(value=>value.id==parseInt(id));
  //   console.log(this.dept);
  // }
  onSubmit(data:any):void{
    console.log(data);
  }
}
