import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Department } from 'src/Model/Department';
import { Employee } from 'src/Model/Employee';
import { Skill } from 'src/Model/Skill';
import { ActivatedRoute } from "@angular/router";
import { EmployeeService } from '../employee.service';
// import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-edit-emp-reactive',
  templateUrl: './edit-emp-reactive.component.html',
  styleUrls: ['./edit-emp-reactive.component.css']
})
export class EditEmpReactiveComponent implements OnInit {
  //Creating array for including departments.
  departments:Department[]=[];

  //Creating array for including skills.
  skills:Skill[]=[];
  
  employee:Employee=
  {
     id:3,
     name:"John",
     salary:10000,
     permanent:false,
     department:{id:1,name:"PayRoll"},
     skill:[{id:1,name:"HTML"},{id:2,name:"CSS"},{id:3,name:"JavaScript"}],
     dateOfBirth:new Date("2019-04-20"),
  };
  empname = new FormControl(this.employee.name);
  empFormreact: FormGroup;
  constructor(private route : ActivatedRoute) {
    //Fetching out the URL'S parameter.
    const employeeId = this.route.snapshot.paramMap.get('id');
    console.log("Employee-Id come from employees edit link:",employeeId);

    this.empFormreact = new FormGroup({
      'name': new FormControl(this.employee.name, [Validators.required,Validators.minLength(4),Validators.maxLength(20)]),
      'salary': new FormControl(this.employee.salary,[Validators.required,Validators.min(5000),Validators.max(50000)]),
      'permanent': new FormControl(this.employee.permanent,[Validators.required]),
      'department': new FormControl(this.employee.department,[Validators.required]),
    });
   }

  ngOnInit(): void {
    this.departments=[{id:1,name:"Payroll"},{id:2,name:"Internal"},{id:3,name:"HR"}];
  }

  get name() { return this.empFormreact.get('name'); }
  get salary(){return this.empFormreact.get('salary');}
  get permanent(){return this.empFormreact.get('permanent');}
  // get department(){return this.empForm.get('department');}
   //Method to be executed on submission of form for displaying form details.
   onSubmit(data:any):void
   {
     console.log(data);
   }
}
