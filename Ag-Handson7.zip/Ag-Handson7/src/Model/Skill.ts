export interface Skill
{
    //Required properties.
    id:number;
    name:string;
}