import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quantity-increment',
  templateUrl: './quantity-increment.component.html',
  styleUrls: ['./quantity-increment.component.css']
})
export class QuantityIncrementComponent implements OnInit {

  msg:string="";
  value:number=0;
  constructor() { }

  ngOnInit(): void {
  }

  clickEvent():any{
    this.msg="Click me button clicked!";
    return this.msg;
  }
  increment():void{
    this.value+=1;
  }
}
