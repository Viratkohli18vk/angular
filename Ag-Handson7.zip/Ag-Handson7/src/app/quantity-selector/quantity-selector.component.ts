import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quantity-selector',
  templateUrl: './quantity-selector.component.html',
  styleUrls: ['./quantity-selector.component.css']
})
export class QuantitySelectorComponent implements OnInit {

  // msg:string="";
  // value:number=0;
  flag:boolean=true;
  quantity:number=0;
  constructor() { }

  ngOnInit(): void {
  }

  // clickEvent():void{
  //   this.msg = "Click Me button clicked!";
  // }
  // increment():void{
  //   this.value+=1;
  // }
  minus():void{
    this.quantity-=1;
    // if(this.quantity>0)
    // {
    //   this.flag=false;
    //   this.quantity-=1;
    // }
    if(this.quantity==0)
      this.flag=true;
    
  }
  plus():void{
    this.quantity+=1;
    if(this.quantity>0)
      this.flag=false;
    
  }

}
