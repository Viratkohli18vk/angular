import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Department } from 'src/Model/Department';
import { Employee } from 'src/Model/Employee';
import { Skill } from 'src/Model/Skill';

@Component({
  selector: 'app-edit-emp-form-builder',
  templateUrl: './edit-emp-form-builder.component.html',
  styleUrls: ['./edit-emp-form-builder.component.css']
})
export class EditEmpFormBuilderComponent implements OnInit {
//Creating array for including departments.
departments:Department[]=[];

//Creating array for including skills.
skills:Skill[]=[];

//Creating an object to store employee details.
employee:Employee=
{
   id:3,
   name:"John",
   salary:10000,
   permanent:false,
   department:{id:1,name:"PayRoll"},
   skill:[{id:1,name:"HTML"},{id:2,name:"CSS"},{id:3,name:"JavaScript"}],
   dateOfBirth:new Date("2019-04-20"),
};

edit_emp: FormGroup;

  constructor(public fb:FormBuilder) { 
    this.edit_emp=this.fb.group(
      {
        name:[this.employee.name,[Validators.required,Validators.minLength(4),Validators.maxLength(20)]],
        salary:[this.employee.salary,[Validators.required,Validators.min(5000),Validators.max(50000)]],
        permanent:[this.employee.permanent,[Validators.required]],
        department:[this.employee.department,[Validators.required]],
        empskills:new FormArray([],[Validators.required])
      });

      this.skills=
      [
        {id:4,name:"Kotlin"},
        {id:5,name:"AI"},
        {id:6,name:"ML"},
        {id:7,name:"IOT"},
        {id:8,name:"Node JS"},
        {id:9,name:"Graphics Design"},
        {id:10,name:"FireBase"},
        {id:11,name:"Flutter"}
      ];
  }

  ngOnInit(): void {
    this.departments=
    [
      {id:1,name:"PayRoll"},
      {id:2,name:"Internal"},
      {id:3,name:"HR"}
    ];
  }

  onSubmit(data:any):void
  {
    console.log(data);
  }

  //Method to record checkboxes choices.
  onCheckBoxChange(e:any):void
  {
    
    const temp=<FormArray> this.edit_emp.get('empskills');
    
    //If a checkbox(e.target) is checked, push its value to temp array. 
    if(e.target.checked)
    temp.push(new FormControl(e.target.value));
    //If a checkbox(e.target) is unchecked, pop its value from temp array.
    else
    {
      let i:number=0;
      
      temp.controls.forEach((item)=>{
        if(item.value==e.target.value)
        {
          temp.removeAt(i);
          return;
        }
        i++;
      });
    }
   
  }


}
